
'use strict';

angular.module('SmartAdmin.Forms').controller('removeModalCtrl', function ($scope, $http, $modalInstance,model,action) {

	 	var vm = this;
		$scope.model = model;
		$scope.action=action;
		
    	$scope.closeModal=function closeModal() {$modalInstance.dismiss('cancel');
	}
	


});




