(function(){
    "use strict";

    angular.module('SmartAdmin.UI', []);
})();