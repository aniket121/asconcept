'use strict';

angular.module('app.home').controller('HomeCtrl', function ($location, $scope) {

  var url = $location.search()
  var data = "sdfsafa";
});