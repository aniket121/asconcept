'use strict';

angular.module('app.category').controller('CategoryCtrl', function ($scope) {


});