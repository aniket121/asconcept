

'use strict';

angular.module('app.dashboard').factory('DashboardResources', function ($http, $q, APP_CONFIG, httpApiConfig) {
    var dfd = $q.defer();

});
