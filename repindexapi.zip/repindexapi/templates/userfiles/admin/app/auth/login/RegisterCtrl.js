angular.module('app.auth').controller('RegisterCtrl', function ($scope, $state, LoginResource) {

    $scope.movetonextpage = false;
    $scope.next = function () {
        console.log("hiding page ??");
        $scope.movetonextpage = true;
    };

    $scope.submitForm = function (RegisterData) {
        console.log("I am entering the inside");
        registerReq = LoginResource.register(RegisterData);
        registerReq.success(function (registerResponse) {
            if (registerResponse.success) {
                $state.go("dashboard");
            }
            else {
                alert("Form is invalid!");
            }

        })
    }
})